
### to run project, do following tasks in project root in order:

* composer install
* cp .env.example .env
* fill .env with your environment values
* run **php public/migrate.php**
* run **php public/queue.php** ***in separate tab in terminal***

### to send sms, call api below with GET method:

`/send/sms?body=test&number=09121234567`

### to see report page, access path below in browser:

`/report`
