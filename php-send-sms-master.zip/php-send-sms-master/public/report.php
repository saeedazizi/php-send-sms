<?php
echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <title>پنل گزارش گیری</title>
</head>
<body>
<div>";
$servername = "127.0.0.1";
$username = "root";
$password = "123";
$dbname = 'digikala';
$tableName = 'log_sms';

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "select count(*) as 'allMessages' from $tableName";
$result = mysqli_query($conn, $sql);

if ($result != TRUE) {
    die("Error: " . $sql . "<br>" . mysqli_error($conn));
}
$count = mysqli_fetch_assoc($result);
echo "<p>" . 'All sms count:' . $count['allMessages'] . "</p>";
$sql = "select api_name, count(*) as 'useCount' from $tableName group by api_name";
$result = mysqli_query($conn, $sql);

if ($result != TRUE) {
    die("Error: " . $sql . "<br>" . mysqli_error($conn));
}
echo "<div><table border='1'>
<caption>Api calls count</caption>
<tr>
<th>ApiName</th>
<th>Count</th>
</tr>";
while($row = mysqli_fetch_array($result))
{
    echo "<tr>";
    echo "<td>" . $row['api_name'] . "</td>";
    echo "<td>" . $row['useCount'] . "</td>";
    echo "</tr>";
}
echo "</table></div><div>";


$sql = "SELECT api_name, 100 * SUM(IF(status='failed', 1, 0)) / COUNT(status) as 'failedPercent' from $tableName group by api_name";
$result = mysqli_query($conn, $sql);

if ($result != TRUE) {
    die("Error: " . $sql . "<br>" . mysqli_error($conn));
}
echo "<table border='1'>
<caption>Api error percent</caption>
<tr>
<th>ApiName</th>
<th>Percent</th>
</tr>";
while($row = mysqli_fetch_array($result))
{
    echo "<tr>";
    echo "<td>" . $row['api_name'] . "</td>";
    echo "<td>" . $row['failedPercent'] . "</td>";
    echo "</tr>";
}
echo "</table></div><div>";

$sql = "SELECT phone, count(*) as sendCount from $tableName group by phone order by sendCount DESC limit 10";
$result = mysqli_query($conn, $sql);

if ($result != TRUE) {
    die("Error: " . $sql . "<br>" . mysqli_error($conn));
}
echo "<table border='1' width='200'>
<caption>10 most phone numbers</caption>
<tr>
<th>Phone</th>
<th>Count</th>
</tr>";
while($row = mysqli_fetch_assoc($result))
{
    echo "<tr>";
    echo "<td>" . $row['phone'] . "</td>";
    echo "<td>" . $row['sendCount'] . "</td>";
    echo "</tr>";
}
echo "</table></div><div>";

echo "<h3>Search  phone number</h3>  
        <form  method='POST' action='#'  id='search'> 
          <input  type='text' name='phone'> 
          <input  type='submit' name='submit' value='search'> 
        </form>";
if (isset($_POST['phone'])) {
    $phone = $_POST['phone'];
    $sql = "SELECT * from $tableName WHERE phone LIKE '%$phone%'";
    $result = mysqli_query($conn, $sql);

    if ($result != TRUE) {
        die("Error: " . $sql . "<br>" . mysqli_error($conn));
    }
    echo "<table border='1'>
    <caption>search result</caption>
    <tr>
    <th>Phone</th>
    <th>apiName</th>
    <th>status</th>
    <th>body</th>
    </tr>";
    while($row = mysqli_fetch_assoc($result))
    {
        echo "<tr>";
        echo "<td>" . $row['phone'] . "</td>";
        echo "<td>" . $row['api_name'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "<td>" . $row['body'] . "</td>";
        echo "</tr>";
    }
    echo "</table></div>";
}

echo "</div></div>
</body>
</html>";
mysqli_close($conn);
