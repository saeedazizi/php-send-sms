<?php

use App\Foundation\Router;
use Symfony\Component\Dotenv\Dotenv;

require_once __DIR__ . '/../vendor/autoload.php';

$dotenv = new Dotenv();
$dotenv->load(__DIR__.'/../.env');

$request = $_SERVER;
$router = new Router($request);
$router->get('/send/sms', '\\App\\Controllers\\SmsController@send');

$router->get('/report', function () {
    include './report.php';
});