<?php

use App\Foundation\QueueHandler;
use Symfony\Component\Dotenv\Dotenv;

require_once __DIR__ . '/../vendor/autoload.php';
$dotenv = new Dotenv();
$dotenv->load(__DIR__.'/../.env');

$jobHandler = new QueueHandler();
$jobHandler->handle();