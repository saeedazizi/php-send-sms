<?php
namespace Test\Unit\Services;
use App\DataContracts\ResponseDto;
use App\Repositories\SmsRepository;
use App\Services\SmsService;
use Exception;
use PHPUnit\Framework\TestCase;

class SmsServiceTest  extends TestCase
{
    public function testSendSmsWhenFirstApiSendMessage()
    {
        $body = 'hi';
        $phone = '09121234567';
        $expectedResult = new ResponseDto();
        $expectedResult->firstApi = true;
        $repository = $this->getMockBuilder(SmsRepository::class)
            ->disableOriginalConstructor()
            ->getMock();
        $repository->expects($this->any())
            ->method('storeLog')
            ->with($this->logicalOr(
                $this->equalTo($body),
                $this->equalTo($phone)
            ))
            ->willReturn(1);
        $repository->expects($this->any())
            ->method('updateStatusToSent')
            ->with(
                $this->equalTo(1)
            );
        $repository->expects($this->any())
            ->method('updateStatusToFail')
            ->with(
                $this->equalTo(1)
            );

        $object = new SmsService($repository);
        $result = $object->sendSms($body, $phone);
        $arrayedResult = json_decode(json_encode($result), true);
        $arrayedExpectedResult = json_decode(json_encode($expectedResult),true);
        $this->assertSame($arrayedExpectedResult, $arrayedResult);
    }

    public function testSendSmsWhenSecondApiSendMessage()
    {
        $body = 'testme';
        $phone = '0912123';
        $expectedResult = new ResponseDto();
        $expectedResult->firstApi = true;
        $expectedResult->secondApi = true;
        $repository = $this->getMockBuilder(SmsRepository::class)
            ->disableOriginalConstructor()
            ->getMock();
        $repository->expects($this->any())
            ->method('storeLog')
            ->with($this->logicalOr(
                $this->equalTo($body),
                $this->equalTo($phone)
            ))
            ->willReturn(1);
        $repository->expects($this->any())
            ->method('updateStatusToSent')
            ->with(
                $this->equalTo(1)
            );
        $repository->expects($this->any())
            ->method('updateStatusToFail')
            ->with(
                $this->equalTo(1)
            );

        $object = new SmsService($repository);
        $result = $object->sendSms($body, $phone);
        $arrayedResult = json_decode(json_encode($result), true);
        $arrayedExpectedResult = json_decode(json_encode($expectedResult),true);
        $this->assertSame($arrayedExpectedResult, $arrayedResult);
    }

    public function testSendSmsToFirstApi()
    {
        $body = 'test';
        $phone = '0912123456';
        $repository = $this->getMockBuilder(SmsRepository::class)
            ->disableOriginalConstructor()
            ->getMock();
        $repository->expects($this->any())
            ->method('storeLog')
            ->with($this->logicalOr(
                $this->equalTo($body),
                $this->equalTo($phone)
            ))
            ->willReturn(1);
        $repository->expects($this->any())
            ->method('updateStatusToSent')
            ->with(
                $this->equalTo(1)
            );
        $repository->expects($this->any())
            ->method('updateStatusToFail')
            ->with(
                $this->equalTo(1)
            );
        $object = new SmsService($repository);
        $result = $this->invokeMethod($object, 'sendSmsToFirstApi', ['body' => $body, 'number' => $phone]);
        $this->assertTrue($result);

    }


    public function testSendSmsToSecondApi()
    {
        $body = 'testi';
        $phone = '0912123';
        $repository = $this->getMockBuilder(SmsRepository::class)
            ->disableOriginalConstructor()
            ->getMock();
        $repository->expects($this->any())
            ->method('storeLog')
            ->with($this->logicalOr(
                $this->equalTo($body),
                $this->equalTo($phone)
            ))
            ->willReturn(1);
        $repository->expects($this->any())
            ->method('updateStatusToSent')
            ->with(
                $this->equalTo(1)
            );
        $repository->expects($this->any())
            ->method('updateStatusToFail')
            ->with(
                $this->equalTo(1)
            );
        $object = new SmsService($repository);
        $result = $this->invokeMethod($object, 'sendSmsToSecondApi', ['body' => $body, 'number' => $phone]);
        $this->assertTrue($result);

    }


    public function testSendSmsToFirstApiWasFailed()
    {
        $body = 'testisdf';
        $phone = '0912123';
        $repository = $this->getMockBuilder(SmsRepository::class)
            ->disableOriginalConstructor()
            ->getMock();
        $repository->expects($this->any())
            ->method('storeLog')
            ->with($this->logicalOr(
                $this->equalTo($body),
                $this->equalTo($phone)
            ))
            ->willReturn(1);
        $repository->expects($this->any())
            ->method('updateStatusToSent')
            ->with(
                $this->equalTo(1)
            );
        $repository->expects($this->any())
            ->method('updateStatusToFail')
            ->with(
                $this->equalTo(1)
            );
        $object = new SmsService($repository);
        $this->expectException(Exception::class);
        $this->invokeMethod($object, 'sendSmsToFirstApi', ['body' => $body, 'number' => $phone]);
    }

    private function invokeMethod(&$object, $methodName, array $parameters = array())
    {
        $reflection = new \ReflectionClass(get_class($object));
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);

        return $method->invokeArgs($object, $parameters);
    }
}