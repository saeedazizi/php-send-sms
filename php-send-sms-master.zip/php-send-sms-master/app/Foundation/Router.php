<?php

namespace App\Foundation;


class Router
{

    private $request;
    public function __construct($request){
        $this->request = $request;
    }
    public function get($route, $file){
        $uri = trim( $this->request['REQUEST_URI'], "/" );
        $uri = explode("?", $uri);
        if($uri[0] == trim($route, "/")){
            if ($file instanceof \Closure) {
                return $file();
            }
            list($controller, $action) = explode('@', $file);
            $controller = new $controller();
            $controller->{$action}();
        }
    }

}