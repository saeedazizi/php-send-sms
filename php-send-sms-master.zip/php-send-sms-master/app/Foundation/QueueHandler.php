<?php
namespace App\Foundation;


use App\Repositories\SmsRepository;
use App\Services\SmsService;
use Redis;

class QueueHandler
{
    private $smsService;

    public function __construct()
    {
        $this->smsService = new SmsService(new SmsRepository());
    }

    public function handle()
    {
        $redis = new Redis();
        $redis->pconnect($_ENV['REDIS_HOST']);
        try {
            while (true) {
                $item = $redis->zRange('send_message', 0,0,true);
                if (empty($item)) {
                    continue;
                }
                $time = array_values($item)[0];
                if ($time > time()) {
                    continue;
                }
                $data = array_keys($item)[0];
                $redis->zRem('send_message', $data);
                $arrayData = unserialize($data);
                echo 'phone: '. $arrayData['phone'] . ' body: ' . $arrayData['body'] . ' time: ' . $arrayData['time'] . "\n";
                $this->smsService->sendSms($arrayData['body'], $arrayData['phone']);
            }
        } catch (\Exception $exception) {
            $this->handle();
        }
    }
}