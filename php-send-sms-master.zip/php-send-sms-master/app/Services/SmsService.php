<?php
namespace App\Services;

use App\DataContracts\ResponseDto;
use App\Exceptions\MysqlQueryException;
use App\Exceptions\SmsApi1Exception;
use App\Exceptions\SmsApi2Exception;
use App\Exceptions\SmsApiException;
use App\Repositories\SmsRepository;
use Redis;

class SmsService
{
    private $repository;

    const API_1 = 'api1';

    const API_2 = 'api2';

    public function __construct(SmsRepository $smsRepository)
    {
        $this->repository = $smsRepository;
    }

    public function sendSms($body, $number)
    {
        $responseDto = new ResponseDto();
        try {
            $logId = $this->repository->storeLog($body, $number, self::API_1);
            $responseDto->firstApi = true;
            $this->sendSmsToFirstApi($body, $number);
            $this->repository->updateStatusToSent($logId);
        } catch (SmsApiException $exception) {
            $responseDto->secondApi = true;
            try {
                $this->repository->updateStatusToFail($logId);
                $logId = $this->repository->storeLog($body, $number, self::API_2);
                $this->sendSmsToSecondApi($body, $number);
                $this->repository->updateStatusToSent($logId);
            } catch (SmsApiException $exception) {
                $responseDto->queue = true;
                $this->repository->updateStatusToFail($logId);
                $this->sendSmsToQueue($body, $number);
            }
        }
        return $responseDto;
    }

    private function sendSmsToFirstApi($body, $number)
    {
        if ((mb_strlen($body)) < 5 || (mb_strlen($number) == 11)) {
            return true;
        }
        throw new SmsApi1Exception(self::API_1 . ' has a problem!');
    }

    private function sendSmsToSecondApi($body, $number)
    {
        if ((mb_strlen($body)) < 10 || (mb_strlen($number) < 11)) {
            return true;
        }
        throw new SmsApi2Exception(self::API_2 . ' has a problem!');
    }

    private function sendSmsToQueue($body, $number)
    {
        $message = [
            'body' => $body,
            'phone' => $number,
            'time' => time(),
            'id' => md5(uniqid(rand(), true))
        ];
        $redis = new Redis();
        $redis->pconnect($_ENV['REDIS_HOST']);
        $redis->zAdd('send_message', strtotime("+1 minutes"), serialize($message));
    }
}