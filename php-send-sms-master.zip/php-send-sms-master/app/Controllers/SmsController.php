<?php
namespace App\Controllers;

use App\Exceptions\MysqlQueryException;
use App\Repositories\SmsRepository;
use App\Services\SmsService;

class SmsController
{
    private $smsService;

    public function __construct()
    {
        $this->smsService = new SmsService(new SmsRepository());
    }

    public function send()
    {
        if (!isset($_GET['body']) || !isset($_GET['number'])) {
            echo $this->jsonResponse('Please send body and number!', 422);
        }
        try {
            echo $this->jsonResponse($this->smsService->sendSms($_GET['body'], $_GET['number']));
        } catch (MysqlQueryException $exception) {
            echo $this->jsonResponse('Input data has problem', 422);
        } catch (\Exception $exception) {
            echo $this->jsonResponse('There is a problem in server', 500);
        }
    }

    public function jsonResponse($message = null, $code = 200)
    {
        header_remove();
        http_response_code($code);
        header("Cache-Control: no-transform,public,max-age=300,s-maxage=900");
        header('Content-Type: application/json');
        $status = array(
            200 => '200 OK',
            400 => '400 Bad Request',
            422 => 'Unprocessable Entity',
            500 => '500 Internal Server Error'
        );
        header('Status: '.$status[$code]);
        return json_encode([
            'status' => $code < 300,
            'message' => $message
        ]);
    }
}