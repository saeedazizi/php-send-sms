<?php
namespace App\Exceptions;

class SmsApi2Exception extends SmsApiException
{

}