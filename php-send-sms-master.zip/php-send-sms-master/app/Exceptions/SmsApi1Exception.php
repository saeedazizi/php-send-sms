<?php
namespace App\Exceptions;

class SmsApi1Exception extends SmsApiException
{

}