<?php

namespace App\Exceptions;


class SmsApiException extends \Exception
{

}