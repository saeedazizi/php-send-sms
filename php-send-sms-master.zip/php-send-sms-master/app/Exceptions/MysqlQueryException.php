<?php

namespace App\Exceptions;


class MysqlQueryException extends \Exception
{

}