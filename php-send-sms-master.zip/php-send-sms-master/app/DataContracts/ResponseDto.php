<?php
namespace App\DataContracts;

class ResponseDto
{
    public $firstApi = false;
    public $secondApi = false;
    public $queue = false;
}