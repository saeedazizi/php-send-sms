<?php

namespace App\Repositories;

use App\Exceptions\MysqlQueryException;
use MongoDB\Driver\Exception\ConnectionException;

class SmsRepository
{
    private $tableName;
    private $connection;

    public function __construct()
    {
        $serverName = $_ENV['DB_HOST'];
        $userName = $_ENV['DB_USERNAME'];
        $password = $_ENV['DB_PASSWORD'];
        $DBName = $_ENV['DB_DATABASE'];
        $this->tableName = $_ENV['DB_TABLE'];
        $this->connection = mysqli_connect($serverName, $userName, $password, $DBName);
        if (!$this->connection) {
            die("Connection failed: " . mysqli_connect_error());
        }
    }

    public function storeLog(string $body, string $number, string $apiName)
    {
        $sql = "INSERT INTO $this->tableName (body, phone, api_name, status) VALUES ('$body', '$number', '$apiName', 'pending')";
        $result = mysqli_query($this->connection, $sql);

        if ($result != TRUE) {
            throw new MysqlQueryException( "Error: " . $sql . "<br>" . mysqli_error($this->connection));
        }
        return $this->connection->insert_id;
    }

    public function updateStatusToSent($logId)
    {
        $sql = "update $this->tableName set status='sent' where id=$logId";
        $result = mysqli_query($this->connection, $sql);

        if ($result != TRUE) {
            throw new MysqlQueryException("Error: " . $sql . "<br>" . mysqli_error($this->connection));
        }

        return true;
    }

    public function updateStatusToFail($logId)
    {
        $sql = "update $this->tableName set status='failed' where id=$logId";
        $result = mysqli_query($this->connection, $sql);

        if ($result != TRUE) {
            throw new MysqlQueryException("Error: " . $sql . "<br>" . mysqli_error($this->connection));
        }

        return true;
    }
}