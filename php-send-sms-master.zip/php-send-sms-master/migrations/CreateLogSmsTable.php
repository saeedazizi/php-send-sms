<?php
namespace Migrations;

class CreateLogSmsTable
{
    public function up()
    {
        $serverName = $_ENV['DB_HOST'];
        $userName = $_ENV['DB_USERNAME'];
        $password = $_ENV['DB_PASSWORD'];
        $DBName = $_ENV['DB_DATABASE'];
        $tableName = $_ENV['DB_TABLE'];
        $this->connection = mysqli_connect($serverName, $userName, $password, $DBName);
        if (!$this->connection) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $sql = "create table IF NOT EXISTS $tableName(id INT AUTO_INCREMENT, body VARCHAR(255), phone VARCHAR(30), api_name VARCHAR(10), status VARCHAR(10), PRIMARY KEY (id), INDEX (phone));
";
        $result = mysqli_query($this->connection, $sql);

        if ($result != TRUE) {
            echo "Error: " . $sql . "<br>" . mysqli_error($this->connection);
        }
    }
}